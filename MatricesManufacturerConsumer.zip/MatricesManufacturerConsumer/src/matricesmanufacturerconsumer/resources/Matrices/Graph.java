package matricesmanufacturerconsumer.resources.Matrices;

public class Graph implements Cloneable{
    public  int Number_of_nodes;
    public  String associations[][];
    public String namesOfNodes[];
      public Graph(int Number_of_nodes,String[][] associations,String[] namesOfNodes){
        this.Number_of_nodes = Number_of_nodes;
        this.associations = associations;
        this.namesOfNodes = namesOfNodes;
      }
    @Override
    public Graph clone() throws CloneNotSupportedException{
    return (Graph)super.clone();
}
}
